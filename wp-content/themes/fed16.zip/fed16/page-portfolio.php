<?php
/**
* Template Name: Portfolio 
* Visar alla inlägg av typen portfolio. 	
**/

get_header();

echo "<i>page-portfolio.php</i><br>";

?>
<h1>Alla mina projekt</h1>

<?php

$portfolio = new WP_Query( array(

		'post_type' => 'fed16_cpt_portfolio',
		'post_status' => 'publish',
		'orderby' => 'title',
		'order' => ASC

	) );

if( $portfolio->have_posts() ) {
	
	while( $portfolio->have_posts() ) {

		$portfolio->the_post();

		echo "<h2>";

		the_title(); 
		echo "<br></h2>";

		//the_post_thumbnail( 'blooper' );

		$bildurl = get_the_post_thumbnail_url();
		?>

		<div class="blooper" style="
		background-image:url(<?php echo $bildurl; ?>); 
		background-size: cover;
		width: 700px;
		height: 500px;"></div>

		<?php

		$terms = wp_get_post_terms( get_the_ID(), 'fed16_projekttyp' );

		foreach($terms as $term) {
			echo $term->name;
		}

		//var_dump($terms);

	}

} else {
	echo "Det finns inga inlägg!";
}

get_footer();