</main> <!-- /wrapper, header.php -->
<?php 
dynamic_sidebar( 'footer1' );

wp_footer(); 

?>
</body>
</html>