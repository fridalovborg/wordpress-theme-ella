<?php get_header(); ?>
<i>index.php</i>
<?php

if(have_posts()) {
	while(have_posts()) {
		the_post(); // hämtar ut inlägget som ett objekt
		// måste vara med för att man ej ska hamna i en evighetsloop
		// samt man ska kunna skriva ut egenskaper som hör till det
		// inlgget
		
		echo "<h3>";
		the_title();
		echo "</h3>";
		the_excerpt();
		?>
		<a href="<?php the_permalink(); ?>"> Läs mer</a>
		<?php
	}
}

get_footer(); ?>