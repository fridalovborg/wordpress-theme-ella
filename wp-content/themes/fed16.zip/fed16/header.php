<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Frida WP</title>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?> >

<nav>
<?php wp_nav_menu(array( 'theme_location' => 'mainmenu' )); ?>
</nav>

<main class="wrapper">
